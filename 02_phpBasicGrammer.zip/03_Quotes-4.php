<?php
  $name = "포르쉐";
  echo "$name님 방가";
  //echo 다음 한칸 띄어쓰기
  //변수는 ''에서는 안나온다
?>