<?php
  $id = "tomato";
  $name = '도만호';
?>

<h3>회원정보</h3>
<p>- ID : <?= $id ?></p>
<p>- NAME : <?= $name ?></p>