<?php
  $a = true;
  $b = false;

  echo $a;
  echo "<br>";
  echo $b;
?>