<?php
  $num1 = "010";
  $num2 = "1010";
  $num3 = "2010";
  $phone_number = $num1."-".$num2."-".$num3;
  echo "phone : $phone_number";

  $email1 = "admin";
  $email2 = "admin.com";
  $email = $email1."@".$email2;
  echo "email : $email";
?>