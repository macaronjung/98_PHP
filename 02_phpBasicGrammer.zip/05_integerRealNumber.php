<?php
  $a = 3769;
  echo "＼$a : $a";

  $a = 126.7;
  echo "＼$a : $a";
?>