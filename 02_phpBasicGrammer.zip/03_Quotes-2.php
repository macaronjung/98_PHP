<?php
  $name = "포르쉐";
  echo $name;
  echo "님 방가";
  echo "<br>";

  $name = "현기차";
  echo $name;
  echo "님 하이";
  //초기에 많이 쓰는 방법
?>