<?php
//변수 무조건 $
  $a = 10;
  $b = 20;
  $c = $a + $b;
  echo "$c <br>"; //변수도 ""안에 삽입(태그도)

  $a = 18.5;
  $b = 37.3;
  $c = $a + $b;
  echo "$c <br>";

  $fruit = "사과";
  echo "$fruit <br>";

  $fruit = "오렌지";
  echo "$fruit <br>";
?>