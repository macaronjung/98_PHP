<?php
  $title = "연락처";
  $name = hong;
  $address = "inchon";
  $phone = "010-6547-6542";
  $email = "user@gmail.com";

  echo $title;
  echo "name : $name<br>";
  echo "address : $address<br>";
  echo "phone : $phone<br>";
  echo "email : $email<br>";
?>