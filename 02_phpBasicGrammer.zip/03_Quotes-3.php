<?php
  $name = "포르쉐";
  echo "$name 님 방가";
  echo "<br>";

  $name = '현기차';
  echo '$name 님 방가';
?>