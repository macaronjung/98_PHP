<?php
  $name = "포르쉐";

  echo "이름 : $name <br>";
  echo '이름 : $name <br>';
?>